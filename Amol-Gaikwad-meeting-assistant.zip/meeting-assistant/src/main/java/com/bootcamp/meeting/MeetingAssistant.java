package com.bootcamp.meeting;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class MeetingAssistant {

    //Externalize String message response formatter using composition.
    private MeetingResponseFormatter formatter;

    public MeetingAssistant(MeetingResponseFormatter formatter) {
        this.formatter = formatter;
    }

    public String findAvailableMeetingSlot(Map<String, MeetingCalendar> participants, LocalDateTime endDateTime) {
        Collection<MeetingCalendar> participantsMeetingCalendars = participants.values();

        List<LocalDateTime> commonMeetingSlots = findCommonMeetingSlotsBetweenParticipants(endDateTime, participantsMeetingCalendars);

        return toString(participants.keySet(), commonMeetingSlots);

    }

    private List<LocalDateTime> findCommonMeetingSlotsBetweenParticipants(LocalDateTime endDateTime, Collection<MeetingCalendar> participantsMeetingCalendars) {
        List<LocalDateTime> commonMeetingSlots = new ArrayList<>();
        for (MeetingCalendar meetingCalendar : participantsMeetingCalendars) {
            if (commonMeetingSlots.isEmpty()) {
                commonMeetingSlots = new ArrayList<>(meetingCalendar.getAvailableTimeSlots(endDateTime));
                continue;
            }
            commonMeetingSlots.retainAll(meetingCalendar.getAvailableTimeSlots(endDateTime));
        }
        return commonMeetingSlots;
    }

    private String toString(Collection<String> participants, List<LocalDateTime> commonMeetingSlots) {
        return (String) formatter.parse(participants, commonMeetingSlots);
    }
}