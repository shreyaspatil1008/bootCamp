package com.bootcamp.meeting;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MeetingCalendar {

    public static final int OFFICE_IN_TIME_IN_HOURS = 8;
    public static final int OFFICE_OUT_TIME_IN_HOURS = 17;
    private Map<LocalDateTime, String> schedule;

    public MeetingCalendar() {
        this.schedule = new HashMap<>();
    }

    public List<LocalDateTime> getAvailableTimeSlots(LocalDateTime endDateTime) {
        List<LocalDateTime> availableTimeSlots = new ArrayList<>();
        LocalDateTime tempTimeSlot = LocalDateTime.of(LocalDate.now(), LocalTime.of(OFFICE_IN_TIME_IN_HOURS, 0));
        while (tempTimeSlot.isBefore(endDateTime)) {
            if (isTimeSlotInOfficeHours(tempTimeSlot) && isNotBooked(tempTimeSlot)) {
                availableTimeSlots.add(tempTimeSlot);
            }
            tempTimeSlot = tempTimeSlot.plusHours(1);
        }
        return availableTimeSlots;
    }

    //Assumption - meetingSlotTime will be added with only hours and every meeting is of one hour.
    public void add(LocalDateTime meetingSlotTime, String meetingTitle) {
        if(!isTimeSlotInOfficeHours(meetingSlotTime)){
            throw new IllegalArgumentException("Meeting Time is outside office hours!");
        }
        schedule.put(meetingSlotTime, meetingTitle);
    }

    public boolean isMeetingSlotAvailable(LocalDateTime meetingSlotTime) {
        return !schedule.containsKey(meetingSlotTime);
    }

    private boolean isNotBooked(LocalDateTime tempTimeSlot) {
        return !schedule.containsKey(tempTimeSlot);
    }

    private boolean isTimeSlotInOfficeHours(LocalDateTime tempTimeSlot) {
        return tempTimeSlot.getHour() >= OFFICE_IN_TIME_IN_HOURS && tempTimeSlot.getHour() < OFFICE_OUT_TIME_IN_HOURS;
    }
}
