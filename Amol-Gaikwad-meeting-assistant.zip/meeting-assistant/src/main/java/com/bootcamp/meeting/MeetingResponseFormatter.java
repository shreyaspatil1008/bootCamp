package com.bootcamp.meeting;

import java.time.LocalDateTime;
import java.util.Collection;

interface MeetingResponseFormatter {
    Object parse(Collection<String> participants, Collection<LocalDateTime> commonMeetingSlots);
}
