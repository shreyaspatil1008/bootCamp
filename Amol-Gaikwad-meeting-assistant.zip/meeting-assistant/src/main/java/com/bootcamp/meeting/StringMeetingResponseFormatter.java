package com.bootcamp.meeting;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Optional;

class StringMeetingResponseFormatter implements MeetingResponseFormatter {

    static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("EEEE dd, h:mm a");

    @Override
    public String parse(Collection<String> participants, Collection<LocalDateTime> commonMeetingSlots) {
        String participantsNames = String.join(", ", participants);
        participantsNames = participantsNames.replaceFirst(",(?=[^,]+$)", " and");

        Optional<LocalDateTime> firstCommonMeetingSlot = commonMeetingSlots.stream().findFirst();
        if (!firstCommonMeetingSlot.isPresent()) {
            return "No available time-slot for " + participantsNames;
        }

        String meetingSlot = firstCommonMeetingSlot.get().format(DATE_TIME_FORMATTER);
        return meetingSlot + ", is the first available time-slot for " + participantsNames + ".";
    }
}
