package com.bootcamp.meeting;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.*;

import static com.bootcamp.meeting.MeetingCalendar.*;
import static com.bootcamp.meeting.MeetingCalendarTestData.*;
import static org.junit.Assert.assertEquals;

public class MeetingAssistantTest {

    private MeetingAssistant meetingAssistant;
    private Map<String, MeetingCalendar> givenParticipants;
    private MeetingResponseFormatter meetingResponseFormatter;

    @Before
    public void setUp() {
        meetingResponseFormatter = new StringMeetingResponseFormatter();
        meetingAssistant = new MeetingAssistant(meetingResponseFormatter);
        givenParticipants = new HashMap<>();
    }

    @Test
    public void shouldReportMeetingSlotTimeForSingleParticipant() {
        givenParticipants.put("Mini", createMeetingCalendarForMini());

        LocalDateTime givenEndDateTime = LocalDateTime.now().plusDays(1);
        givenEndDateTime = givenEndDateTime.withHour(OFFICE_OUT_TIME_IN_HOURS).withMinute(0).withSecond(0).withNano(0);

        String actualResponse = meetingAssistant.findAvailableMeetingSlot(givenParticipants, givenEndDateTime);

        LocalDateTime expectedMeetingTime = LocalDateTime.now().withHour(11).withMinute(0).withSecond(0).withNano(0);
        String expectedResponse = (String) meetingResponseFormatter.parse(givenParticipants.keySet(), Arrays.asList(expectedMeetingTime));
        assertEquals("First empty meeting slot should be reported", expectedResponse, actualResponse);
    }

    @Test
    public void shouldReportMeetingSlotTimeFor2Participants() {
        givenParticipants.put("Mini", createMeetingCalendarForMini());
        givenParticipants.put("Frank", createMeetingCalendarForFrank());

        LocalDateTime givenEndDateTime = LocalDateTime.now().plusDays(1);
        givenEndDateTime = givenEndDateTime.withHour(OFFICE_OUT_TIME_IN_HOURS).withMinute(0).withSecond(0).withNano(0);

        String actualResponse = meetingAssistant.findAvailableMeetingSlot(givenParticipants, givenEndDateTime);

        LocalDateTime expectedMeetingTime = LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0).withNano(0);
        String expectedResponse = (String) meetingResponseFormatter.parse(givenParticipants.keySet(), Arrays.asList(expectedMeetingTime));
        assertEquals("First empty meeting slot should be reported", expectedResponse, actualResponse);
    }

    @Test
    public void shouldReportMeetingSlotTimeFor3Participants() {
        givenParticipants.put("Frank", createMeetingCalendarForFrank());
        givenParticipants.put("Janet", createMeetingCalendarForJanet());
        givenParticipants.put("Brad", createMeetingCalendarForBrad());

        LocalDateTime endDateTime = LocalDateTime.now().plusDays(1);
        endDateTime = endDateTime.withHour(OFFICE_OUT_TIME_IN_HOURS).withMinute(0).withSecond(0).withNano(0);

        String actualResponse = meetingAssistant.findAvailableMeetingSlot(givenParticipants, endDateTime);

        LocalDateTime expectedMeetingTime = LocalDateTime.now().plusDays(1).withHour(14).withMinute(0).withSecond(0).withNano(0);
        String expectedResponse = (String) meetingResponseFormatter.parse(givenParticipants.keySet(), Arrays.asList(expectedMeetingTime));
        assertEquals("First empty meeting slot should be reported", expectedResponse, actualResponse);
    }

    @Test
    public void shouldReportNoMeetingSlotTimeForBusyParticipants() {
        givenParticipants.put("Janet", createMeetingCalendarForJanet());
        givenParticipants.put("Busy Bee", createMeetingCalendarForBusyBee());

        LocalDateTime endDateTime = LocalDateTime.now();
        endDateTime = endDateTime.withHour(OFFICE_OUT_TIME_IN_HOURS).withMinute(0).withSecond(0).withNano(0);

        String actualResponse = meetingAssistant.findAvailableMeetingSlot(givenParticipants, endDateTime);

        String expectedResponse = (String) meetingResponseFormatter.parse(givenParticipants.keySet(), new ArrayList<>());
        assertEquals("No available time-slot should be available", expectedResponse, actualResponse);
    }
}
