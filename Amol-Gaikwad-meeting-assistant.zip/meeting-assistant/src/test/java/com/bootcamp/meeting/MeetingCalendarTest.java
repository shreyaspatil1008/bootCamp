package com.bootcamp.meeting;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bootcamp.meeting.MeetingCalendar.OFFICE_IN_TIME_IN_HOURS;
import static com.bootcamp.meeting.MeetingCalendar.OFFICE_OUT_TIME_IN_HOURS;
import static org.junit.Assert.assertEquals;

public class MeetingCalendarTest {

    private MeetingCalendar meetingCalendar;

    @Before
    public void setUp(){
        meetingCalendar = new MeetingCalendar();
    }

    @Test
    public void shouldGetAllAvailableEmptySlotsForEndDateTimeOnSameDay() {
        LocalDateTime givenEndDateTime = LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0);
        addSomeFakeMeetingsForTheSameDay();

        List<LocalDateTime> actualAvailableSlots = meetingCalendar.getAvailableTimeSlots(givenEndDateTime);

        List<LocalDateTime> expectedAvailableSlots = Arrays.asList(LocalDateTime.now().withHour(11).withMinute(0).withSecond(0).withNano(0));
        assertEquals(expectedAvailableSlots, actualAvailableSlots);
    }

    @Test
    public void shouldGetAllAvailableEmptySlotsForEndDateTimeOnNextDay() {
        LocalDateTime endDateTime = LocalDateTime.now();
        endDateTime = endDateTime.plusDays(1).withHour(12).withMinute(0).withSecond(0).withNano(0);
        addFakeMeetingsForEntireSameDayAndSomeOnNextDay();

        List<LocalDateTime> actualAvailableSlots = meetingCalendar.getAvailableTimeSlots(endDateTime);

        List<LocalDateTime> expectedAvailableSlots = new ArrayList<>();
        expectedAvailableSlots.add(LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0).withNano(0));
        expectedAvailableSlots.add(LocalDateTime.now().plusDays(1).withHour(11).withMinute(0).withSecond(0).withNano(0));
        assertEquals(expectedAvailableSlots, actualAvailableSlots);
    }

    @Test
    public void shouldAcceptMeetingInWorkingHours(){
        LocalDateTime meetingSlotTime = LocalDateTime.of(LocalDate.now(), LocalTime.of(OFFICE_IN_TIME_IN_HOURS, 0));
        Assert.assertTrue(meetingCalendar.isMeetingSlotAvailable(meetingSlotTime));

        meetingCalendar.add(meetingSlotTime, "Busy");

        Assert.assertFalse(meetingCalendar.isMeetingSlotAvailable(meetingSlotTime));
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAcceptMeetingBeforeOfficeInTime(){
        LocalDateTime meetingSlotTime = LocalDateTime.of(LocalDate.now(), LocalTime.of(OFFICE_IN_TIME_IN_HOURS-1, 0));
        Assert.assertTrue(meetingCalendar.isMeetingSlotAvailable(meetingSlotTime));

        meetingCalendar.add(meetingSlotTime, "Busy");
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldNotAcceptMeetingAfterOfficeOutTime(){
        LocalDateTime meetingSlotTime = LocalDateTime.of(LocalDate.now(), LocalTime.of(OFFICE_OUT_TIME_IN_HOURS, 0));
        Assert.assertTrue(meetingCalendar.isMeetingSlotAvailable(meetingSlotTime));

        meetingCalendar.add(meetingSlotTime, "Busy");
    }

    private void addFakeMeetingsForEntireSameDayAndSomeOnNextDay() {
        meetingCalendar.add(LocalDateTime.now().withHour(8).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(9).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(11).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(13).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(15).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(16).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(8).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(9).withMinute(0).withSecond(0).withNano(0), "");
    }

    private void addSomeFakeMeetingsForTheSameDay() {
        meetingCalendar.add(LocalDateTime.now().withHour(8).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(9).withMinute(0).withSecond(0).withNano(0), "");
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "");
    }
}
