package com.bootcamp.meeting;

import java.time.LocalDateTime;

public class MeetingCalendarTestData {
    public static MeetingCalendar createMeetingCalendarForBrad() {
        MeetingCalendar meetingCalendar = new MeetingCalendar();
        meetingCalendar.add(LocalDateTime.now().withHour(8).withMinute(0).withSecond(0).withNano(0), "Meet Mini");
        meetingCalendar.add(LocalDateTime.now().withHour(9).withMinute(0).withSecond(0).withNano(0), "Meet Frank");
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "Team Planning");
        meetingCalendar.add(LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().withHour(13).withMinute(0).withSecond(0).withNano(0), "Meet Frank");
        meetingCalendar.add(LocalDateTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(15).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");

        return meetingCalendar;
    }

    public static MeetingCalendar createMeetingCalendarForMini() {
        MeetingCalendar meetingCalendar = new MeetingCalendar();
        meetingCalendar.add(LocalDateTime.now().withHour(8).withMinute(0).withSecond(0).withNano(0), "Meet Brad");
        meetingCalendar.add(LocalDateTime.now().withHour(9).withMinute(0).withSecond(0).withNano(0), "Meet Janet");
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "Team Planning");
        meetingCalendar.add(LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(15).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");

        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(8).withMinute(0).withSecond(0).withNano(0), "Meet Janet");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(9).withMinute(0).withSecond(0).withNano(0), "Meet Brad");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(12).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(15).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");
        return meetingCalendar;
    }

    public static MeetingCalendar createMeetingCalendarForJanet() {
        MeetingCalendar meetingCalendar = new MeetingCalendar();
        meetingCalendar.add(LocalDateTime.now().withHour(9).withMinute(0).withSecond(0).withNano(0), "Meet Mini");
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "Team Planning");
        meetingCalendar.add(LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().withHour(13).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0), "Busy");

        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(8).withMinute(0).withSecond(0).withNano(0), "Meet Mini");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(9).withMinute(0).withSecond(0).withNano(0), "Meet Frank");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(12).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(13).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(15).withMinute(0).withSecond(0).withNano(0), "Meet Frank");
        return meetingCalendar;
    }

    public static MeetingCalendar createMeetingCalendarForFrank() {
        MeetingCalendar meetingCalendar = new MeetingCalendar();
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "Team Planning");
        meetingCalendar.add(LocalDateTime.now().withHour(11).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(13).withMinute(0).withSecond(0).withNano(0), "Meet Brad");
        meetingCalendar.add(LocalDateTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(15).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");

        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(8).withMinute(0).withSecond(0).withNano(0), "Meet Brad");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(9).withMinute(0).withSecond(0).withNano(0), "Meet Janet");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(11).withMinute(0).withSecond(0).withNano(0), "Lunch");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(15).withMinute(0).withSecond(0).withNano(0), "Meet Janet");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");
        return meetingCalendar;
    }

    public static MeetingCalendar createMeetingCalendarForBusyBee() {
        MeetingCalendar meetingCalendar = new MeetingCalendar();
        meetingCalendar.add(LocalDateTime.now().withHour(8).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(9).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(10).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(11).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(12).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(13).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(15).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");


        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(8).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(9).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(11).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(12).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(13).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(14).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(15).withMinute(0).withSecond(0).withNano(0), "Busy");
        meetingCalendar.add(LocalDateTime.now().plusDays(1).withHour(16).withMinute(0).withSecond(0).withNano(0), "Busy");

        return meetingCalendar;
    }
}
