package com.tdd.demo;

public interface LocationAware {

	public void locationChangedTo(String location);

}
