package com.tdd.demo;

public interface MediaPlayer {

	void play(String song);

}
