package com.tdd.demo;

public interface MediaTracker {

	public void currentSongFinished();

}
