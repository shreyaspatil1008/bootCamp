package com.tdd.demo;

public interface PlayListService {

	String songFor(String location);

}
