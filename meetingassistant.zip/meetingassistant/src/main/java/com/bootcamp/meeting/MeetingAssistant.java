package com.bootcamp.meeting;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MeetingAssistant {


    public String findAvailableMeetingSlot(Map<String, MeetingCalendar> participants, LocalDateTime endDateTime) {
        Collection<MeetingCalendar> participantsMeetingCalendars = participants.values();
        List<LocalDateTime> commonMeetingSlots = findCommonMeetingSlotsBetweenParticipants(endDateTime, participantsMeetingCalendars);
        return format(participants.keySet(), commonMeetingSlots);
    }

    private List<LocalDateTime> findCommonMeetingSlotsBetweenParticipants(LocalDateTime endDateTime, Collection<MeetingCalendar> participantsMeetingCalendars) {
        List<LocalDateTime> commonMeetingSlots = new ArrayList<>();
        for (MeetingCalendar meetingCalendar : participantsMeetingCalendars) {
            if (commonMeetingSlots.isEmpty()) {
                commonMeetingSlots = new ArrayList<>(meetingCalendar.getAvailableTimeSlots(endDateTime));
                continue;
            }
            commonMeetingSlots.retainAll(meetingCalendar.getAvailableTimeSlots(endDateTime));
        }
        return commonMeetingSlots;
    }

    public String format(Collection<String> participants, Collection<LocalDateTime> commonMeetingSlots) {
        String participantsNames = String.join(", ", participants);
        participantsNames = participantsNames.replaceFirst(",(?=[^,]+$)", " and");

        Optional<LocalDateTime> firstCommonMeetingSlot = commonMeetingSlots.stream().findFirst();
        if (!firstCommonMeetingSlot.isPresent()) {
            return "No available time-slot for " + participantsNames;
        }

        String meetingSlot = firstCommonMeetingSlot.get().format(DateTimeFormatter.ofPattern("EEEE dd, h:mm a"));
        return meetingSlot + ", is the first available time-slot for " + participantsNames + ".";
    }
}